import React from 'react';
import { Button } from './ui/button';
import { useQuery } from '@tanstack/react-query';
import { RiMapPinLine, RiStarFill, RiStarHalfFill, RiStarLine } from 'react-icons/ri';
import type { Accommodation } from '@/types';

const AccommodationCard: React.FC<{ accommodation: Accommodation }> = ({ accommodation }) => {
  // Generate star rating elements based on rating
  const renderStars = () => {
    const rating = parseFloat(accommodation.rating);
    const stars = [];
    
    for (let i = 1; i <= 5; i++) {
      if (i <= rating) {
        stars.push(<RiStarFill key={i} className="text-sm" />);
      } else if (i - 0.5 <= rating) {
        stars.push(<RiStarHalfFill key={i} className="text-sm" />);
      } else {
        stars.push(<RiStarLine key={i} className="text-sm" />);
      }
    }
    
    return stars;
  };
  
  return (
    <div className="glass rounded-xl overflow-hidden transition-all duration-300 card-hover">
      <img 
        src={accommodation.image} 
        alt={accommodation.name} 
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="font-bold mb-1">{accommodation.name}</h3>
        <div className="flex items-center mb-2">
          <RiMapPinLine className="text-primary mr-1 text-sm" />
          <span className="text-sm text-muted-foreground">{accommodation.location}</span>
        </div>
        <div className="flex items-center mb-3">
          <div className="flex text-[#FFBD4D]">
            {renderStars()}
          </div>
          <span className="text-xs ml-1 text-muted-foreground">({accommodation.reviews} reviews)</span>
        </div>
        <div className="flex justify-between items-center">
          <p className="font-bold">${accommodation.pricePerNight.toLocaleString()}<span className="text-xs text-muted-foreground">/night</span></p>
          <Button variant="outline" size="sm" className="text-sm border-primary text-primary hover:bg-primary hover:text-white">
            View
          </Button>
        </div>
      </div>
    </div>
  );
};

const AccommodationSkeleton: React.FC = () => {
  return (
    <div className="glass rounded-xl overflow-hidden">
      <div className="h-48 bg-gray-800 animate-pulse"></div>
      <div className="p-4">
        <div className="h-5 bg-gray-700 rounded-md w-3/4 mb-1 animate-pulse"></div>
        <div className="h-4 bg-gray-700 rounded-md w-1/2 mb-2 animate-pulse"></div>
        <div className="h-4 bg-gray-700 rounded-md w-32 mb-3 animate-pulse"></div>
        <div className="flex justify-between items-center">
          <div className="h-5 bg-gray-700 rounded-md w-24 animate-pulse"></div>
          <div className="h-8 bg-gray-700 rounded-md w-16 animate-pulse"></div>
        </div>
      </div>
    </div>
  );
};

const Accommodations: React.FC = () => {
  const { data: accommodations = [], isLoading } = useQuery<Accommodation[]>({
    queryKey: ['/api/accommodations'],
  });

  return (
    <section id="accommodations" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Space Accommodations</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From orbital hotels to Martian habitats, find your perfect space home away from home.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {isLoading ? (
            <>
              <AccommodationSkeleton />
              <AccommodationSkeleton />
              <AccommodationSkeleton />
              <AccommodationSkeleton />
            </>
          ) : (
            accommodations.map(accommodation => (
              <AccommodationCard key={accommodation.id} accommodation={accommodation} />
            ))
          )}
        </div>
        
        <div className="text-center mt-12">
          <Button variant="outline" className="border-2">
            Browse All Accommodations
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Accommodations;
