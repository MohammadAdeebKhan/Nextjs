import React from 'react';
import { Button } from './ui/button';
import { Link } from 'wouter';

const CallToAction: React.FC = () => {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="glass rounded-2xl p-8 md:p-12 relative overflow-hidden">
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-primary rounded-full opacity-20 blur-3xl"></div>
          <div className="absolute -bottom-16 -left-16 w-48 h-48 bg-[#FF4D5E] rounded-full opacity-20 blur-3xl"></div>
          
          <div className="grid md:grid-cols-2 gap-8 items-center relative z-10">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Begin Your Space Journey?</h2>
              <p className="text-muted-foreground mb-6">
                Create your account today and start planning your first adventure beyond Earth. 
                Early registrations receive priority booking access.
              </p>
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                <Link href="/register">
                  <Button>
                    Create Account
                  </Button>
                </Link>
                <Link href="#packages">
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1454789548928-9efd52dc4031?q=80&w=800&auto=format" 
                alt="Space with Earth view" 
                className="rounded-xl w-full h-64 object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
