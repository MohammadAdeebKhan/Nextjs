import React from 'react';
import { Button } from './ui/button';
import { useQuery } from '@tanstack/react-query';
import { RiStarFill } from 'react-icons/ri';
import type { Destination } from '@/types';

const DestinationCard: React.FC<{ destination: Destination }> = ({ destination }) => {
  return (
    <div className="glass rounded-xl overflow-hidden transition-all duration-300 card-hover">
      <div className="relative h-48">
        <img 
          src={destination.image} 
          alt={destination.name} 
          className="object-cover w-full h-full"
        />
        {destination.tag && (
          <div className={`absolute top-4 right-4 ${
            destination.tag === 'Most Popular' 
              ? 'bg-primary' 
              : destination.tag === 'Adventure' 
                ? 'bg-[#FF4D5E]' 
                : 'bg-primary'
          } text-white text-sm px-3 py-1 rounded-full`}>
            {destination.tag}
          </div>
        )}
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xl font-bold">{destination.name}</h3>
          <div className="flex items-center text-[#FFBD4D]">
            <RiStarFill className="mr-1" />
            <span>{destination.rating}</span>
          </div>
        </div>
        <p className="text-muted-foreground text-sm mb-4">{destination.description}</p>
        <div className="flex justify-between items-center">
          <div>
            <span className="text-xs text-muted-foreground">Starting from</span>
            <p className="text-xl font-bold text-white">${destination.startingPrice.toLocaleString()}</p>
          </div>
          <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
            View Details
          </Button>
        </div>
      </div>
    </div>
  );
};

const DestinationSkeleton: React.FC = () => {
  return (
    <div className="glass rounded-xl overflow-hidden">
      <div className="h-48 bg-gray-800 animate-pulse"></div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-3">
          <div className="h-6 bg-gray-700 rounded-md w-1/2 animate-pulse"></div>
          <div className="h-6 bg-gray-700 rounded-md w-12 animate-pulse"></div>
        </div>
        <div className="h-4 bg-gray-700 rounded-md w-full mb-2 animate-pulse"></div>
        <div className="h-4 bg-gray-700 rounded-md w-2/3 mb-4 animate-pulse"></div>
        <div className="flex justify-between items-center">
          <div>
            <div className="h-3 bg-gray-700 rounded-md w-20 mb-1 animate-pulse"></div>
            <div className="h-6 bg-gray-700 rounded-md w-24 animate-pulse"></div>
          </div>
          <div className="h-10 bg-gray-700 rounded-md w-28 animate-pulse"></div>
        </div>
      </div>
    </div>
  );
};

const Destinations: React.FC = () => {
  const { data: destinations = [], isLoading } = useQuery<Destination[]>({
    queryKey: ['/api/destinations'],
  });

  return (
    <section id="destinations" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Popular Destinations</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover our most sought-after cosmic destinations, from lunar bases to Martian colonies.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            <>
              <DestinationSkeleton />
              <DestinationSkeleton />
              <DestinationSkeleton />
            </>
          ) : (
            destinations.map(destination => (
              <DestinationCard key={destination.id} destination={destination} />
            ))
          )}
        </div>
        
        <div className="text-center mt-12">
          <Button variant="outline" className="border-2">
            View All Destinations
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Destinations;
