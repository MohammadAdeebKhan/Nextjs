import React, { useState } from 'react';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from './ui/accordion';
import { useQuery } from '@tanstack/react-query';
import type { FAQ } from '@/types';

const Faq: React.FC = () => {
  const { data: faqs = [], isLoading } = useQuery<FAQ[]>({
    queryKey: ['/api/faqs'],
  });

  return (
    <section id="faq" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Everything you need to know about your space journey.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto divide-y divide-gray-800">
          {isLoading ? (
            // Loading skeleton
            Array(5).fill(0).map((_, i) => (
              <div key={i} className="py-6">
                <div className="h-6 bg-gray-800 rounded w-3/4 animate-pulse mb-3"></div>
                {i === 0 && (
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-800 rounded w-full animate-pulse"></div>
                    <div className="h-4 bg-gray-800 rounded w-5/6 animate-pulse"></div>
                    <div className="h-4 bg-gray-800 rounded w-4/6 animate-pulse"></div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq) => (
                <AccordionItem key={faq.id} value={faq.id.toString()}>
                  <AccordionTrigger className="text-lg font-medium text-left hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
        </div>
      </div>
    </section>
  );
};

export default Faq;
