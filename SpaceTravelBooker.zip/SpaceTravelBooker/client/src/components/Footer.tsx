import React from 'react';
import { Link } from 'wouter';
import { RiRocketFill, RiInstagramLine, RiTwitterXLine, RiFacebookCircleLine, RiYoutubeLine } from 'react-icons/ri';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#050811] py-12 relative">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center mb-4">
              <div className="mr-2 text-primary text-2xl">
                <RiRocketFill />
              </div>
              <h1 className="text-xl font-bold text-white">CosmoTravel</h1>
            </div>
            <p className="text-muted-foreground mb-6">
              Pioneering the future of space tourism since 2030. Making the cosmos accessible to everyone.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-white transition-colors">
                <RiInstagramLine className="text-xl" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-white transition-colors">
                <RiTwitterXLine className="text-xl" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-white transition-colors">
                <RiFacebookCircleLine className="text-xl" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-white transition-colors">
                <RiYoutubeLine className="text-xl" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Destinations</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Lunar Bases</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Earth Orbit</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Mars Colonies</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Asteroid Belt</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Europa Tours</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Safety Record</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Careers</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Press</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Sustainability</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Booking Info</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Cancellations</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-white transition-colors">Travel Insurance</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm mb-4 md:mb-0">© 2030 CosmoTravel Inc. All rights reserved.</p>
          <div className="flex space-x-6">
            <a href="#" className="text-muted-foreground hover:text-white transition-colors text-sm">Privacy Policy</a>
            <a href="#" className="text-muted-foreground hover:text-white transition-colors text-sm">Terms of Service</a>
            <a href="#" className="text-muted-foreground hover:text-white transition-colors text-sm">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
