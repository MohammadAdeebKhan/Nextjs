import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from './ui/button';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';
import { RiRocketLine, RiMenu3Fill } from 'react-icons/ri';

const Header: React.FC = () => {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="glass fixed w-full z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="mr-2 text-primary text-2xl">
              <RiRocketLine />
            </div>
            <Link href="/">
              <h1 className="text-xl md:text-2xl font-bold text-white glow cursor-pointer">
                CosmoTravel
              </h1>
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#destinations" className="font-medium hover:text-primary transition-colors duration-300">
              Destinations
            </a>
            <a href="#packages" className="font-medium hover:text-primary transition-colors duration-300">
              Packages
            </a>
            <a href="#accommodations" className="font-medium hover:text-primary transition-colors duration-300">
              Accommodations
            </a>
            <a href="#faq" className="font-medium hover:text-primary transition-colors duration-300">
              FAQ
            </a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Link href="/login">
              <Button variant="outline" className="hidden md:block">
                Sign In
              </Button>
            </Link>
            <Link href="/register">
              <Button>Book Now</Button>
            </Link>
            
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon">
                  <RiMenu3Fill className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col gap-4 pt-10">
                  <Link href="/" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start">
                      Home
                    </Button>
                  </Link>
                  <Link href="/login" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start">
                      Sign In
                    </Button>
                  </Link>
                  <Link href="/register" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start">
                      Register
                    </Button>
                  </Link>
                  <Link href="/dashboard" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start">
                      Dashboard
                    </Button>
                  </Link>
                  
                  <div className="border-t my-2"></div>
                  
                  <a href="#destinations" className="px-4 py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    Destinations
                  </a>
                  <a href="#packages" className="px-4 py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    Packages
                  </a>
                  <a href="#accommodations" className="px-4 py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    Accommodations
                  </a>
                  <a href="#faq" className="px-4 py-2 hover:text-primary" onClick={() => setIsMenuOpen(false)}>
                    FAQ
                  </a>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
