import React, { useState } from 'react';
import { 
  Card, 
  CardContent 
} from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from './ui/select';
import { RiSearchLine } from 'react-icons/ri';
import { DEPARTURE_POINTS, TRAVELER_OPTIONS } from '@/lib/constants';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import type { Destination } from '@/types';

const Hero: React.FC = () => {
  const { toast } = useToast();
  const [searchForm, setSearchForm] = useState({
    departureFrom: DEPARTURE_POINTS[0],
    destination: '',
    departureDate: '',
    travelers: TRAVELER_OPTIONS[0]
  });

  const { data: destinations = [] } = useQuery<Destination[]>({
    queryKey: ['/api/destinations'],
  });

  const handleChange = (field: string, value: string) => {
    setSearchForm({
      ...searchForm,
      [field]: value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchForm.destination || !searchForm.departureDate) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields to search for journeys.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Searching for journeys",
      description: "We're finding the best space trips for you!",
    });
    
    // Here we would typically use the form data to search or redirect
    console.log("Search form submitted:", searchForm);
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <div className="stars fixed inset-0 opacity-30 z-0"></div>
      
      <div className="container mx-auto px-4 py-20 md:py-40 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Your Journey to the <span className="text-primary glow">Stars</span> Begins Now
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Discover interplanetary travel experiences with unparalleled luxury and adventure. The cosmos awaits.
            </p>
            
            <Card className="glass max-w-lg mx-auto md:mx-0">
              <CardContent className="p-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="departureFrom">Departure From</Label>
                      <Select 
                        value={searchForm.departureFrom} 
                        onValueChange={(value) => handleChange('departureFrom', value)}
                      >
                        <SelectTrigger className="bg-[#050811] border-gray-700">
                          <SelectValue placeholder="Select departure location" />
                        </SelectTrigger>
                        <SelectContent>
                          {DEPARTURE_POINTS.map((point) => (
                            <SelectItem key={point} value={point}>
                              {point}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="destination">Destination</Label>
                      <Select 
                        value={searchForm.destination} 
                        onValueChange={(value) => handleChange('destination', value)}
                      >
                        <SelectTrigger className="bg-[#050811] border-gray-700">
                          <SelectValue placeholder="Select destination" />
                        </SelectTrigger>
                        <SelectContent>
                          {destinations.map((destination) => (
                            <SelectItem key={destination.id} value={destination.id.toString()}>
                              {destination.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="departureDate">Departure Date</Label>
                      <Input 
                        type="date" 
                        id="departureDate"
                        className="bg-[#050811] border-gray-700"
                        value={searchForm.departureDate}
                        onChange={(e) => handleChange('departureDate', e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="travelers">Travelers</Label>
                      <Select 
                        value={searchForm.travelers} 
                        onValueChange={(value) => handleChange('travelers', value)}
                      >
                        <SelectTrigger className="bg-[#050811] border-gray-700">
                          <SelectValue placeholder="Select number of travelers" />
                        </SelectTrigger>
                        <SelectContent>
                          {TRAVELER_OPTIONS.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <Button type="submit" className="w-full">
                    <RiSearchLine className="mr-2" /> Find Journeys
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
          
          <div className="hidden md:block relative">
            <img 
              src="https://images.unsplash.com/photo-1614728263952-84ea256f9679?q=80&w=1200&auto=format" 
              alt="Space shuttle launch" 
              className="rounded-2xl animate-float shadow-lg"
            />
            <div className="absolute -top-10 right-10 w-20 h-20 bg-primary rounded-full opacity-30 blur-xl"></div>
            <div className="absolute bottom-10 left-0 w-16 h-16 bg-[#FF4D5E] rounded-full opacity-20 blur-xl"></div>
          </div>
        </div>
      </div>
      
      {/* Animated elements */}
      <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white rounded-full animate-pulse"></div>
      <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-[#FFBD4D] rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
      <div className="absolute bottom-1/4 right-1/3 w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
    </section>
  );
};

export default Hero;
