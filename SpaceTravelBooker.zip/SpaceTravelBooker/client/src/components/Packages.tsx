import React from 'react';
import { Button } from './ui/button';
import { RiCheckLine, RiCloseLine, RiRocketLine, RiRocketFill, RiVipCrownFill } from 'react-icons/ri';
import { PACKAGE_TYPES } from '@/lib/constants';

const Packages: React.FC = () => {
  return (
    <section id="packages" className="py-20 relative bg-[#050811]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Travel Packages</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Choose the perfect space travel experience tailored to your adventure preferences.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Economy Package */}
          <div className="glass rounded-xl overflow-hidden transition-all duration-300 card-hover border border-gray-800">
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-[#121726] rounded-full flex items-center justify-center mx-auto mb-6 border border-gray-700">
                <RiRocketLine className="text-2xl text-muted-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-2">{PACKAGE_TYPES[0].name}</h3>
              <p className="text-5xl font-bold mb-2">
                <span className="text-lg">$</span>{PACKAGE_TYPES[0].price.toLocaleString()}
              </p>
              <p className="text-sm text-muted-foreground mb-6">Per person / one way</p>
              
              <ul className="text-left mb-8 space-y-3">
                {PACKAGE_TYPES[0].features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    {feature.included ? (
                      <>
                        <RiCheckLine className="text-[#10B981] mr-2" />
                        <span>{feature.name}</span>
                      </>
                    ) : (
                      <>
                        <RiCloseLine className="text-muted-foreground mr-2" />
                        <span className="text-muted-foreground">{feature.name}</span>
                      </>
                    )}
                  </li>
                ))}
              </ul>
              
              <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-white">
                Select Package
              </Button>
            </div>
          </div>
          
          {/* Premium Package */}
          <div className="glass rounded-xl overflow-hidden transition-all duration-300 card-hover border border-primary relative transform scale-105">
            <div className="absolute top-0 left-0 w-full bg-primary text-white text-center py-2 text-sm font-medium">
              MOST POPULAR
            </div>
            <div className="p-8 text-center pt-12">
              <div className="w-16 h-16 bg-primary bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6 border border-primary">
                <RiRocketFill className="text-2xl text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">{PACKAGE_TYPES[1].name}</h3>
              <p className="text-5xl font-bold mb-2">
                <span className="text-lg">$</span>{PACKAGE_TYPES[1].price.toLocaleString()}
              </p>
              <p className="text-sm text-muted-foreground mb-6">Per person / one way</p>
              
              <ul className="text-left mb-8 space-y-3">
                {PACKAGE_TYPES[1].features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    {feature.included ? (
                      <>
                        <RiCheckLine className="text-[#10B981] mr-2" />
                        <span>{feature.name}</span>
                      </>
                    ) : (
                      <>
                        <RiCloseLine className="text-muted-foreground mr-2" />
                        <span className="text-muted-foreground">{feature.name}</span>
                      </>
                    )}
                  </li>
                ))}
              </ul>
              
              <Button className="w-full">
                Select Package
              </Button>
            </div>
          </div>
          
          {/* Luxury Package */}
          <div className="glass rounded-xl overflow-hidden transition-all duration-300 card-hover border border-[#FFBD4D]">
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-[#FFBD4D] bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6 border border-[#FFBD4D]">
                <RiVipCrownFill className="text-2xl text-[#FFBD4D]" />
              </div>
              <h3 className="text-xl font-bold mb-2">{PACKAGE_TYPES[2].name}</h3>
              <p className="text-5xl font-bold mb-2">
                <span className="text-lg">$</span>{PACKAGE_TYPES[2].price.toLocaleString()}
              </p>
              <p className="text-sm text-muted-foreground mb-6">Per person / one way</p>
              
              <ul className="text-left mb-8 space-y-3">
                {PACKAGE_TYPES[2].features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    {feature.included ? (
                      <>
                        <RiCheckLine className="text-[#10B981] mr-2" />
                        <span>{feature.name}</span>
                      </>
                    ) : (
                      <>
                        <RiCloseLine className="text-muted-foreground mr-2" />
                        <span className="text-muted-foreground">{feature.name}</span>
                      </>
                    )}
                  </li>
                ))}
              </ul>
              
              <Button variant="outline" className="w-full border-[#FFBD4D] text-[#FFBD4D] hover:bg-[#FFBD4D] hover:text-white">
                Select Package
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Packages;
