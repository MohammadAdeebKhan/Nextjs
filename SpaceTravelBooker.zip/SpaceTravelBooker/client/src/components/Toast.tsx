import React, { useEffect, useState } from 'react';
import { XIcon } from 'lucide-react';
import { RiNotification3Fill } from 'react-icons/ri';

interface ToastProps {
  title: string;
  description: string;
  type?: 'success' | 'info' | 'warning';
  duration?: number;
  onClose?: () => void;
}

const Toast: React.FC<ToastProps> = ({ 
  title, 
  description, 
  type = 'success', 
  duration = 5000,
  onClose
}) => {
  const [isVisible, setIsVisible] = useState(true);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      if (onClose) onClose();
    }, duration);
    
    return () => clearTimeout(timer);
  }, [duration, onClose]);
  
  if (!isVisible) return null;
  
  const bgColor = type === 'success' 
    ? 'bg-[#10B981] bg-opacity-20 text-[#10B981]' 
    : type === 'warning' 
      ? 'bg-[#F59E0B] bg-opacity-20 text-[#F59E0B]'
      : 'bg-primary bg-opacity-20 text-primary';
  
  return (
    <div className="fixed bottom-4 right-4 glass rounded-lg p-4 flex items-center space-x-3 z-50 animate-float">
      <div className={`${bgColor} p-2 rounded-full`}>
        <RiNotification3Fill />
      </div>
      <div>
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      <button 
        className="text-muted-foreground hover:text-white transition-colors"
        onClick={() => {
          setIsVisible(false);
          if (onClose) onClose();
        }}
      >
        <XIcon className="h-4 w-4" />
      </button>
    </div>
  );
};

export default Toast;
