import React from 'react';
import { Button } from './ui/button';
import { 
  RiRocketFill, 
  RiRefreshLine, 
  RiHealthBookFill, 
  RiLuggageCartFill, 
  RiVidiconFill,
  RiNotification3Fill
} from 'react-icons/ri';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import type { Booking, User } from '@/types';

// Mock user for demo
const demoUser: User = {
  id: 1,
  username: 'demo_user',
  fullName: 'Demo User',
  email: 'demo@example.com',
  createdAt: new Date().toISOString()
};

// Function to calculate countdown
const calculateCountdown = (departureDate: string) => {
  const departure = new Date(departureDate).getTime();
  const now = new Date().getTime();
  const distance = departure - now;
  
  if (distance < 0) return "Departed";
  
  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  
  return `${days}d:${hours}h:${minutes}m`;
};

const UserDashboard: React.FC = () => {
  const { data: userBookings = [], isLoading } = useQuery<Booking[]>({
    queryKey: [`/api/users/${demoUser.id}/bookings`],
    enabled: false, // Disable this query since we don't have a real user in this demo
  });
  
  // Mock data for demonstration
  const upcomingBookings = [
    {
      id: 1,
      destinationName: "Earth to Lunar Base Alpha",
      departureDate: "2023-12-15T00:00:00.000Z",
      packageType: "Premium Journey",
      status: "active"
    },
    {
      id: 2,
      destinationName: "Lunar Base to Mars Nova",
      departureDate: "2024-02-03T00:00:00.000Z",
      packageType: "Luxury Expedition",
      status: "active"
    }
  ];
  
  const historicBookings = [
    {
      id: 3,
      destinationName: "Earth to Space Station Nexus",
      completedDate: "2023-09-22T00:00:00.000Z"
    },
    {
      id: 4,
      destinationName: "Lunar Orbit Experience",
      completedDate: "2023-07-08T00:00:00.000Z"
    }
  ];

  return (
    <section className="py-20 relative bg-[#050811]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Your Space Travel Dashboard</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Manage all your cosmic journeys in one place with our intuitive dashboard.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="col-span-1 lg:col-span-2 glass rounded-xl overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">Your Upcoming Journeys</h3>
                <Button variant="ghost" size="icon">
                  <RiRefreshLine />
                </Button>
              </div>
              
              {upcomingBookings.length > 0 ? (
                upcomingBookings.map((booking) => (
                  <div key={booking.id} className="bg-[#121726] rounded-lg p-4 mb-4 border border-gray-800">
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                      <div className="flex items-center mb-4 md:mb-0">
                        <div className="mr-4 bg-primary bg-opacity-10 rounded-full p-3">
                          <RiRocketFill className="text-2xl text-primary" />
                        </div>
                        <div>
                          <h4 className="font-bold text-white">{booking.destinationName}</h4>
                          <p className="text-sm text-muted-foreground">
                            Departing {new Date(booking.departureDate).toLocaleDateString('en-US', { 
                              month: 'short', 
                              day: 'numeric', 
                              year: 'numeric' 
                            })} • {booking.packageType}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">Countdown</div>
                          <div className="text-lg font-bold text-white">
                            {calculateCountdown(booking.departureDate)}
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="border-primary text-primary hover:bg-primary hover:text-white">
                          Manage
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No upcoming journeys found.</p>
                  <Link href="/">
                    <Button variant="link">Book your first space adventure</Button>
                  </Link>
                </div>
              )}
              
              <div className="mt-6">
                <h3 className="text-xl font-bold mb-4">Travel History</h3>
                {historicBookings.map((booking) => (
                  <div key={booking.id} className="bg-[#121726] rounded-lg p-4 border border-gray-800 mb-4 opacity-70">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-medium">{booking.destinationName}</h4>
                        <p className="text-sm text-muted-foreground">
                          Completed on {new Date(booking.completedDate).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric', 
                            year: 'numeric' 
                          })}
                        </p>
                      </div>
                      <Button variant="link" size="sm" className="text-primary">
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="glass rounded-xl overflow-hidden">
            <div className="p-6">
              <h3 className="text-xl font-bold mb-6">Travel Tips & Preparation</h3>
              
              <div className="space-y-4">
                <div className="bg-[#121726] rounded-lg p-4 border border-gray-800">
                  <div className="flex items-start">
                    <div className="bg-primary bg-opacity-10 rounded-full p-2 mr-3 mt-1">
                      <RiHealthBookFill className="text-primary" />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Pre-Flight Medical Checkup</h4>
                      <p className="text-sm text-muted-foreground">
                        Your Lunar Base Alpha journey requires a medical assessment 7 days before departure.
                      </p>
                      <Button variant="link" size="sm" className="mt-2 text-sm text-primary p-0">
                        Schedule Now
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="bg-[#121726] rounded-lg p-4 border border-gray-800">
                  <div className="flex items-start">
                    <div className="bg-[#FFBD4D] bg-opacity-10 rounded-full p-2 mr-3 mt-1">
                      <RiLuggageCartFill className="text-[#FFBD4D]" />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Packing Recommendations</h4>
                      <p className="text-sm text-muted-foreground">
                        View our AI-generated packing list for your upcoming lunar journey.
                      </p>
                      <Button variant="link" size="sm" className="mt-2 text-sm text-primary p-0">
                        View List
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="bg-[#121726] rounded-lg p-4 border border-gray-800">
                  <div className="flex items-start">
                    <div className="bg-[#FF4D5E] bg-opacity-10 rounded-full p-2 mr-3 mt-1">
                      <RiVidiconFill className="text-[#FF4D5E]" />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Training Videos</h4>
                      <p className="text-sm text-muted-foreground">
                        Complete your zero-gravity orientation videos before your journey.
                      </p>
                      <div className="mt-2 flex space-x-2">
                        <div className="h-1 bg-[#10B981] rounded-full w-14"></div>
                        <div className="h-1 bg-gray-700 rounded-full w-8"></div>
                        <div className="h-1 bg-gray-700 rounded-full w-8"></div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">1 of 3 completed</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-[#121726] rounded-lg p-4 border border-gray-800">
                  <div className="flex items-start">
                    <div className="bg-primary bg-opacity-10 rounded-full p-2 mr-3 mt-1">
                      <RiNotification3Fill className="text-primary" />
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Launch Notifications</h4>
                      <p className="text-sm text-muted-foreground">
                        Set your preferred notification schedule for your upcoming launch.
                      </p>
                      <div className="mt-3 grid grid-cols-3 gap-2">
                        <Button variant="outline" size="sm" className="border-gray-700 text-xs py-1 h-auto">24h</Button>
                        <Button variant="outline" size="sm" className="border-primary bg-primary bg-opacity-20 text-primary text-xs py-1 h-auto">12h</Button>
                        <Button variant="outline" size="sm" className="border-gray-700 text-xs py-1 h-auto">6h</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UserDashboard;
