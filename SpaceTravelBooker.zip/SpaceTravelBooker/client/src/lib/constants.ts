// Colors
export const COLORS = {
  spaceBlue: '#121726',
  cosmicBlack: '#050811',
  nebulaGradient: 'linear-gradient(to right, #7B4DFF, #FF4D5E)',
  nebulaPurple: '#7B4DFF',
  marsRed: '#FF4D5E',
  jupiterAmber: '#FFBD4D',
  starlight: '#E2E8F0',
  moonGray: '#94A3B8',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444'
};

// Package Types
export const PACKAGE_TYPES = [
  {
    id: 'economy',
    name: 'Economy Experience',
    price: 12500,
    features: [
      { name: 'Standard cabin accommodations', included: true },
      { name: 'Shared zero-gravity experience', included: true },
      { name: '3 space meals & hydration', included: true },
      { name: 'Basic health monitoring', included: true },
      { name: 'Private quarters', included: false },
      { name: 'Spacewalk opportunity', included: false },
    ]
  },
  {
    id: 'premium',
    name: 'Premium Journey',
    price: 24999,
    features: [
      { name: 'Enhanced private cabin', included: true },
      { name: 'Extended zero-gravity sessions', included: true },
      { name: 'Gourmet space cuisine', included: true },
      { name: 'Advanced health monitoring', included: true },
      { name: 'Private quarters', included: true },
      { name: 'Spacewalk opportunity', included: false },
    ]
  },
  {
    id: 'luxury',
    name: 'Luxury Expedition',
    price: 49999,
    features: [
      { name: 'Premium suite with Earth view', included: true },
      { name: 'Unlimited zero-gravity access', included: true },
      { name: "Chef's table dining experience", included: true },
      { name: 'Comprehensive medical suite', included: true },
      { name: 'Luxury private quarters', included: true },
      { name: 'Private spacewalk experience', included: true },
    ]
  }
];

// Departure points
export const DEPARTURE_POINTS = [
  "Earth - Kennedy Space Center",
  "Earth - Baikonur Cosmodrome",
  "Earth - SpaceX Launch Site",
  "Lunar Colony Alpha"
];

// Traveler options
export const TRAVELER_OPTIONS = [
  "1 Traveler",
  "2 Travelers",
  "3 Travelers",
  "4+ Travelers"
];
