import React from 'react';
import Header from '@/components/Header';
import UserDashboard from '@/components/UserDashboard';
import Footer from '@/components/Footer';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RiRocketLine, RiHotelLine, RiHistoryLine, RiSettings3Line } from 'react-icons/ri';
import { useQuery } from '@tanstack/react-query';
import type { User } from '@/types';

const Dashboard: React.FC = () => {
  // This would typically fetch from an API with current user data
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ['/api/me'],
    enabled: false, // Disable this query since we don't have auth setup
  });
  
  // For demo purposes
  const isLoggedIn = false;
  
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <div className="stars fixed inset-0 opacity-30 z-0"></div>
        <Header />
        
        <div className="container mx-auto px-4 pt-32 pb-20">
          <div className="max-w-md mx-auto glass rounded-xl p-8 text-center">
            <h1 className="text-2xl font-bold mb-4">Login Required</h1>
            <p className="text-muted-foreground mb-6">Please log in to access your dashboard and manage your space journeys.</p>
            <div className="flex flex-col gap-2">
              <Link href="/login">
                <Button className="w-full">Log In</Button>
              </Link>
              <Link href="/register">
                <Button variant="outline" className="w-full">Create Account</Button>
              </Link>
            </div>
          </div>
        </div>
        
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="stars fixed inset-0 opacity-30 z-0"></div>
      <Header />
      
      <div className="container mx-auto px-4 pt-32 pb-20">
        <div className="glass rounded-xl p-6 mb-8">
          <h1 className="text-2xl font-bold mb-2">Welcome, {user?.fullName || 'Space Traveler'}</h1>
          <p className="text-muted-foreground">Manage your cosmic adventures and prepare for lift-off</p>
        </div>
        
        <Tabs defaultValue="journeys" className="space-y-8">
          <TabsList className="grid grid-cols-4 max-w-xl mx-auto">
            <TabsTrigger value="journeys" className="flex gap-2 items-center">
              <RiRocketLine /> Journeys
            </TabsTrigger>
            <TabsTrigger value="accommodations" className="flex gap-2 items-center">
              <RiHotelLine /> Stays
            </TabsTrigger>
            <TabsTrigger value="history" className="flex gap-2 items-center">
              <RiHistoryLine /> History
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex gap-2 items-center">
              <RiSettings3Line /> Settings
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="journeys">
            <UserDashboard />
          </TabsContent>
          
          <TabsContent value="accommodations">
            <div className="glass rounded-xl p-8 text-center">
              <h2 className="text-xl font-bold mb-4">Your Space Accommodations</h2>
              <p className="text-muted-foreground mb-6">You haven't booked any space accommodations yet.</p>
              <Link href="#accommodations">
                <Button>Browse Accommodations</Button>
              </Link>
            </div>
          </TabsContent>
          
          <TabsContent value="history">
            <div className="glass rounded-xl p-8 text-center">
              <h2 className="text-xl font-bold mb-4">Travel History</h2>
              <p className="text-muted-foreground mb-6">Your space travel history will appear here after your first journey.</p>
            </div>
          </TabsContent>
          
          <TabsContent value="settings">
            <div className="glass rounded-xl p-8">
              <h2 className="text-xl font-bold mb-4">Account Settings</h2>
              <div className="space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium mb-1">Full Name</label>
                  <input type="text" value={user?.fullName || ''} disabled className="w-full bg-[#050811] border border-gray-700 rounded-lg px-4 py-3" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <input type="email" value={user?.email || ''} disabled className="w-full bg-[#050811] border border-gray-700 rounded-lg px-4 py-3" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Username</label>
                  <input type="text" value={user?.username || ''} disabled className="w-full bg-[#050811] border border-gray-700 rounded-lg px-4 py-3" />
                </div>
                <Button variant="outline" className="mt-4">Update Profile</Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <Footer />
    </div>
  );
};

export default Dashboard;
