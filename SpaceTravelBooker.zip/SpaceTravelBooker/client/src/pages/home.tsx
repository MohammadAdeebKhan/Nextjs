import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Destinations from '@/components/Destinations';
import Packages from '@/components/Packages';
import Accommodations from '@/components/Accommodations';
import UserDashboard from '@/components/UserDashboard';
import Faq from '@/components/Faq';
import CallToAction from '@/components/CallToAction';
import Footer from '@/components/Footer';
import Toast from '@/components/Toast';

const Home: React.FC = () => {
  const [showToast, setShowToast] = useState(false);
  
  useEffect(() => {
    // Show notification after 3 seconds
    const timer = setTimeout(() => {
      setShowToast(true);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <div className="stars fixed inset-0 opacity-30 z-0"></div>
      
      <Header />
      <Hero />
      <Destinations />
      <Packages />
      <Accommodations />
      <UserDashboard />
      <Faq />
      <CallToAction />
      <Footer />
      
      {showToast && (
        <Toast 
          title="New space flight added!" 
          description="Check out our Europa expedition."
          onClose={() => setShowToast(false)}
        />
      )}
    </div>
  );
};

export default Home;
