export interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
  createdAt: string;
}

export interface Destination {
  id: number;
  name: string;
  description: string;
  image: string;
  rating: string;
  startingPrice: number;
  tag?: string;
  popularity: number;
}

export interface Accommodation {
  id: number;
  name: string;
  location: string;
  image: string;
  rating: string;
  reviews: number;
  pricePerNight: number;
  destinationId: number;
}

export interface Booking {
  id: number;
  userId: number;
  destinationId: number;
  departureFrom: string;
  travelers: number;
  departureDate: string;
  packageType: string;
  status: string;
  createdAt: string;
  bookingPrice: number;
  accommodationId?: number;
}

export interface FAQ {
  id: number;
  question: string;
  answer: string;
  isExpanded: boolean;
}

export interface BookingFormData {
  departureFrom: string;
  destination: string;
  departureDate: string;
  travelers: string;
}

export interface LoginFormData {
  username: string;
  password: string;
}

export interface RegisterFormData {
  username: string;
  password: string;
  fullName: string;
  email: string;
}
