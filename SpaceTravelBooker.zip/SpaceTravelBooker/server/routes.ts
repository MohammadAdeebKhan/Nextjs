import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertBookingSchema, insertUserSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefixed with /api
  const apiRouter = app.route("/api");

  // Get all destinations
  app.get("/api/destinations", async (req: Request, res: Response) => {
    try {
      const destinations = await storage.getDestinations();
      res.status(200).json(destinations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch destinations" });
    }
  });

  // Get a single destination
  app.get("/api/destinations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const destination = await storage.getDestination(id);
      
      if (!destination) {
        return res.status(404).json({ message: "Destination not found" });
      }
      
      res.status(200).json(destination);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch destination" });
    }
  });

  // Get all accommodations
  app.get("/api/accommodations", async (req: Request, res: Response) => {
    try {
      const accommodations = await storage.getAccommodations();
      res.status(200).json(accommodations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch accommodations" });
    }
  });

  // Get accommodations by destination
  app.get("/api/destinations/:id/accommodations", async (req: Request, res: Response) => {
    try {
      const destinationId = parseInt(req.params.id);
      const accommodations = await storage.getAccommodationsByDestination(destinationId);
      res.status(200).json(accommodations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch accommodations" });
    }
  });

  // Get all faqs
  app.get("/api/faqs", async (req: Request, res: Response) => {
    try {
      const faqs = await storage.getFaqs();
      res.status(200).json(faqs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch FAQs" });
    }
  });

  // User Registration
  app.post("/api/register", async (req: Request, res: Response) => {
    try {
      const validatedUser = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(validatedUser.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const newUser = await storage.createUser(validatedUser);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // User Login
  app.post("/api/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // In a real app, you would create a session here
      // For this demo, we'll just return the user without the password
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to login" });
    }
  });

  // Get user bookings
  app.get("/api/users/:id/bookings", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const bookings = await storage.getBookingsByUser(userId);
      res.status(200).json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  // Create a booking
  app.post("/api/bookings", async (req: Request, res: Response) => {
    try {
      const validatedBooking = insertBookingSchema.parse(req.body);
      
      // Check if user exists
      const user = await storage.getUser(validatedBooking.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if destination exists
      const destination = await storage.getDestination(validatedBooking.destinationId);
      if (!destination) {
        return res.status(404).json({ message: "Destination not found" });
      }
      
      // Check accommodation if provided
      if (validatedBooking.accommodationId) {
        const accommodation = await storage.getAccommodation(validatedBooking.accommodationId);
        if (!accommodation) {
          return res.status(404).json({ message: "Accommodation not found" });
        }
      }
      
      const newBooking = await storage.createBooking(validatedBooking);
      res.status(201).json(newBooking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
