import { 
  users, 
  destinations, 
  accommodations, 
  bookings, 
  faqs,
  type User, 
  type InsertUser, 
  type Destination, 
  type Accommodation, 
  type Booking, 
  type FAQ 
} from "@shared/schema";

// Expanded storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Destination methods
  getDestinations(): Promise<Destination[]>;
  getDestination(id: number): Promise<Destination | undefined>;
  createDestination(destination: Destination): Promise<Destination>;
  
  // Accommodation methods
  getAccommodations(): Promise<Accommodation[]>;
  getAccommodation(id: number): Promise<Accommodation | undefined>;
  getAccommodationsByDestination(destinationId: number): Promise<Accommodation[]>;
  createAccommodation(accommodation: Accommodation): Promise<Accommodation>;
  
  // Booking methods
  getBookings(): Promise<Booking[]>;
  getBooking(id: number): Promise<Booking | undefined>;
  getBookingsByUser(userId: number): Promise<Booking[]>;
  createBooking(booking: Booking): Promise<Booking>;
  updateBooking(id: number, booking: Partial<Booking>): Promise<Booking>;
  
  // FAQ methods
  getFaqs(): Promise<FAQ[]>;
  getFaq(id: number): Promise<FAQ | undefined>;
  createFaq(faq: FAQ): Promise<FAQ>;
  updateFaq(id: number, faq: Partial<FAQ>): Promise<FAQ>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private destinations: Map<number, Destination>;
  private accommodations: Map<number, Accommodation>;
  private bookings: Map<number, Booking>;
  private faqs: Map<number, FAQ>;
  
  private userIdCounter: number;
  private destinationIdCounter: number;
  private accommodationIdCounter: number;
  private bookingIdCounter: number;
  private faqIdCounter: number;

  constructor() {
    this.users = new Map();
    this.destinations = new Map();
    this.accommodations = new Map();
    this.bookings = new Map();
    this.faqs = new Map();
    
    this.userIdCounter = 1;
    this.destinationIdCounter = 1;
    this.accommodationIdCounter = 1;
    this.bookingIdCounter = 1;
    this.faqIdCounter = 1;
    
    // Seed initial data
    this.seedData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  // Destination methods
  async getDestinations(): Promise<Destination[]> {
    return Array.from(this.destinations.values());
  }
  
  async getDestination(id: number): Promise<Destination | undefined> {
    return this.destinations.get(id);
  }
  
  async createDestination(destination: Destination): Promise<Destination> {
    const id = this.destinationIdCounter++;
    const newDestination = { ...destination, id };
    this.destinations.set(id, newDestination);
    return newDestination;
  }
  
  // Accommodation methods
  async getAccommodations(): Promise<Accommodation[]> {
    return Array.from(this.accommodations.values());
  }
  
  async getAccommodation(id: number): Promise<Accommodation | undefined> {
    return this.accommodations.get(id);
  }
  
  async getAccommodationsByDestination(destinationId: number): Promise<Accommodation[]> {
    return Array.from(this.accommodations.values()).filter(
      (accommodation) => accommodation.destinationId === destinationId
    );
  }
  
  async createAccommodation(accommodation: Accommodation): Promise<Accommodation> {
    const id = this.accommodationIdCounter++;
    const newAccommodation = { ...accommodation, id };
    this.accommodations.set(id, newAccommodation);
    return newAccommodation;
  }
  
  // Booking methods
  async getBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }
  
  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }
  
  async getBookingsByUser(userId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      (booking) => booking.userId === userId
    );
  }
  
  async createBooking(booking: Booking): Promise<Booking> {
    const id = this.bookingIdCounter++;
    const now = new Date();
    const newBooking = { ...booking, id, createdAt: now };
    this.bookings.set(id, newBooking);
    return newBooking;
  }
  
  async updateBooking(id: number, booking: Partial<Booking>): Promise<Booking> {
    const existingBooking = this.bookings.get(id);
    if (!existingBooking) {
      throw new Error(`Booking with id ${id} not found`);
    }
    
    const updatedBooking = { ...existingBooking, ...booking };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }
  
  // FAQ methods
  async getFaqs(): Promise<FAQ[]> {
    return Array.from(this.faqs.values());
  }
  
  async getFaq(id: number): Promise<FAQ | undefined> {
    return this.faqs.get(id);
  }
  
  async createFaq(faq: FAQ): Promise<FAQ> {
    const id = this.faqIdCounter++;
    const newFaq = { ...faq, id };
    this.faqs.set(id, newFaq);
    return newFaq;
  }
  
  async updateFaq(id: number, faq: Partial<FAQ>): Promise<FAQ> {
    const existingFaq = this.faqs.get(id);
    if (!existingFaq) {
      throw new Error(`FAQ with id ${id} not found`);
    }
    
    const updatedFaq = { ...existingFaq, ...faq };
    this.faqs.set(id, updatedFaq);
    return updatedFaq;
  }
  
  // Seed data
  private seedData() {
    // Seed destinations
    const destinations: Destination[] = [
      {
        id: this.destinationIdCounter++,
        name: "Lunar Base Alpha",
        description: "The Moon's premier research and tourism colony with Earth views.",
        image: "https://images.unsplash.com/photo-1614314169000-4744c61fa0e3?q=80&w=800&auto=format",
        rating: "4.9",
        startingPrice: 24999,
        tag: "Most Popular",
        popularity: 10
      },
      {
        id: this.destinationIdCounter++,
        name: "Mars Nova Colony",
        description: "Experience the frontier of human civilization on the red planet.",
        image: "https://images.unsplash.com/photo-1465101162946-4377e57745c3?q=80&w=800&auto=format",
        rating: "4.7",
        startingPrice: 49999,
        tag: "Adventure",
        popularity: 8
      },
      {
        id: this.destinationIdCounter++,
        name: "Low Earth Orbit",
        description: "Luxury orbital hotel with panoramic Earth views and zero gravity suites.",
        image: "https://images.unsplash.com/photo-1506443432602-ac2fcd6f54e0?q=80&w=800&auto=format",
        rating: "4.5",
        startingPrice: 12500,
        tag: "Exclusive",
        popularity: 9
      }
    ];
    
    destinations.forEach(destination => {
      this.destinations.set(destination.id, destination);
    });
    
    // Seed accommodations
    const accommodations: Accommodation[] = [
      {
        id: this.accommodationIdCounter++,
        name: "Orbital Grand Hotel",
        location: "Low Earth Orbit",
        image: "https://images.unsplash.com/photo-1517976487492-5750f3195933?q=80&w=800&auto=format",
        rating: "4.5",
        reviews: 128,
        pricePerNight: 3500,
        destinationId: 3
      },
      {
        id: this.accommodationIdCounter++,
        name: "Artemis Lunar Suites",
        location: "Lunar Base Alpha",
        image: "https://images.unsplash.com/photo-1543083115-638c4ef3fc35?q=80&w=800&auto=format",
        rating: "5.0",
        reviews: 84,
        pricePerNight: 4200,
        destinationId: 1
      },
      {
        id: this.accommodationIdCounter++,
        name: "Mars Red Habitat",
        location: "Mars Nova Colony",
        image: "https://images.unsplash.com/photo-1547234935-80c7145ec969?q=80&w=800&auto=format",
        rating: "4.0",
        reviews: 39,
        pricePerNight: 5750,
        destinationId: 2
      },
      {
        id: this.accommodationIdCounter++,
        name: "Space Station Nexus",
        location: "Earth Orbit - ISS Nova",
        image: "https://images.unsplash.com/photo-1508966672060-2e78a19c256d?q=80&w=800&auto=format",
        rating: "3.5",
        reviews: 62,
        pricePerNight: 2900,
        destinationId: 3
      }
    ];
    
    accommodations.forEach(accommodation => {
      this.accommodations.set(accommodation.id, accommodation);
    });
    
    // Seed FAQs
    const faqs: FAQ[] = [
      {
        id: this.faqIdCounter++,
        question: "How physically demanding is space travel?",
        answer: "Modern space travel has become more accessible than ever. While still requiring basic fitness levels, our spacecraft are designed to minimize physical strain. All travelers undergo a simple medical assessment and receive pre-flight training to prepare for zero-gravity environments.",
        isExpanded: true
      },
      {
        id: this.faqIdCounter++,
        question: "What amenities are available during space travel?",
        answer: "Our spacecraft are equipped with advanced amenities including comfortable sleeping quarters, gourmet dining options, entertainment systems, communication links to Earth, and specially designed hygiene facilities. Premium and luxury packages offer additional comforts such as private quarters and enhanced dining experiences.",
        isExpanded: false
      },
      {
        id: this.faqIdCounter++,
        question: "How long does the journey take to each destination?",
        answer: "Travel times vary by destination: Low Earth Orbit takes approximately 6 hours, Lunar Base Alpha journeys are 3-4 days, while Mars Nova Colony expeditions require 4-6 months depending on planetary alignment. All travel times include comfortable accommodation and activities during transit.",
        isExpanded: false
      },
      {
        id: this.faqIdCounter++,
        question: "What happens in case of an emergency?",
        answer: "Safety is our highest priority. All spacecraft are equipped with redundant safety systems, medical facilities, and emergency escape pods. Our crew members are extensively trained in emergency procedures, and we maintain constant communication with mission control. We've established emergency protocols for various scenarios to ensure passenger safety.",
        isExpanded: false
      },
      {
        id: this.faqIdCounter++,
        question: "Can I change or cancel my booking?",
        answer: "Yes, bookings can be modified or canceled according to our flexibility policy. Changes made more than 90 days before departure incur no fees. Cancellations 60-90 days before departure receive an 80% refund, 30-60 days receive 50%, while cancellations less than 30 days before departure are non-refundable. Premium insurance options are available for additional flexibility.",
        isExpanded: false
      }
    ];
    
    faqs.forEach(faq => {
      this.faqs.set(faq.id, faq);
    });
  }
}

export const storage = new MemStorage();
