import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const destinations = pgTable("destinations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  rating: text("rating").notNull(),
  startingPrice: integer("starting_price").notNull(),
  tag: text("tag"),
  popularity: integer("popularity").default(0),
});

export const accommodations = pgTable("accommodations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  image: text("image").notNull(),
  rating: text("rating").notNull(),
  reviews: integer("reviews").notNull(),
  pricePerNight: integer("price_per_night").notNull(),
  destinationId: integer("destination_id").notNull(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  destinationId: integer("destination_id").notNull(),
  departureFrom: text("departure_from").notNull(),
  travelers: integer("travelers").notNull(),
  departureDate: timestamp("departure_date").notNull(),
  packageType: text("package_type").notNull(),
  status: text("status").default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  bookingPrice: integer("booking_price").notNull(),
  accommodationId: integer("accommodation_id"),
});

export const faqs = pgTable("faqs", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  isExpanded: boolean("is_expanded").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
});

export const insertDestinationSchema = createInsertSchema(destinations);
export const insertAccommodationSchema = createInsertSchema(accommodations);
export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
});
export const insertFaqSchema = createInsertSchema(faqs);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Destination = typeof destinations.$inferSelect;
export type Accommodation = typeof accommodations.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type FAQ = typeof faqs.$inferSelect;
